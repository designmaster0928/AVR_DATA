/*
 * ATmega16_Accelerometer.c
 * http://www.electronicwings.com
 *
 */ 


#define F_CPU 8000000UL								/* Define CPU clock Frequency e.g. here its 8MHz */
#include <avr/io.h>									/* Include AVR std. library file */
#include <util/delay.h>								/* Include defined delay header file */
#include <stdlib.h>									/* Include standard library file */
#include <math.h>									/* Include math header file */
#include "USART_RS232_H_file.h"						/* Include USART header file */


void ADC_Init()										/* ADC InitialiAzouttion function */
{
	DDRA = 0x00;							        /* Make ADC port as input */
	ADCSRA = 0x87;									/* Enable ADC, with freq/128  */
	ADMUX = 0x40;									/* Vref: Avcc, ADC channel: 0 */
}

int ADC_Read(char channel)							/* ADC Read function */
{
	ADMUX = 0x40 | (channel & 0x07);				/* set input channel to read */
	ADCSRA |= (1<<ADSC);							/* Start ADC conversion */
	while (!(ADCSRA & (1<<ADIF)));					/* Wait until end of conversion by polling ADC interrupt flag */
	ADCSRA |= (1<<ADIF);							/* Clear interrupt flag */
	_delay_ms(1);									/* Wait a little bit */
	return ADCW;									/* Return ADC word */
}

void SendSerial(char* str, double value, char unit)
{
	char buffer[10];
	dtostrf(value,4,2,buffer);
	USART_SendString(str);							/* Send Name string */
	USART_SendString(buffer);						/* Send value */
	USART_TxChar(unit);								/* Send unit char */
	USART_TxChar('\t');								/* Send tab char */
	_delay_ms(10);
}

int main(void)
{
	int ADC_X_VALUE,ADC_Y_VALUE,ADC_Z_VALUE;
	double Axout,Ayout,Azout,theta, psy, phi,roll,pitch,yaw;
	USART_Init(9600);								/* Initialize USART with 9600 Baud rate */
	ADC_Init();										/* Initialize ADC */

	while(1)
	{
		ADC_X_VALUE = ADC_Read(0);					/* Read X, Y, Z axis ADC value */
		ADC_Y_VALUE = ADC_Read(1);
		ADC_Z_VALUE = ADC_Read(2);

		Axout = (((double)(ADC_X_VALUE*5)/1.024)-1700.0)/330.0; /* Convert values in g unit */
		Ayout = (((double)(ADC_Y_VALUE*5)/1.024)-1700.0)/330.0;
		Azout = (((double)(ADC_Z_VALUE*5)/1.024)-1700.0)/330.0;

		theta = atan(Axout/(sqrt((pow (Ayout,2.0))+(pow (Azout,2.0)))))*57.29577951; /* Calculate angles */
		psy =  atan(Ayout/(sqrt((pow (Axout,2.0))+(pow (Azout,2.0)))))*57.29577951;
		phi =  atan((sqrt((pow (Ayout,2.0))+(pow (Axout,2.0))))/Azout)*57.29577951;

		roll = (atan2(Ayout,Azout))*57.29577951+180;
		pitch =  (atan2(Azout,Axout))*57.29577951+180;
		yaw =  (atan2(Axout,Ayout))*57.29577951+180;
		
		SendSerial("Axout = ",Axout,'g');			/* Send All value serially */
		SendSerial("Ayout = ",Ayout,'g');
		SendSerial("Azout = ",Azout,'g');

		SendSerial("Theta = ",theta,248);
		SendSerial("Psy = ",psy,248);
		SendSerial("Phi = ",phi,248);

		SendSerial("Roll = ",roll,248);
		SendSerial("Pitch = ",pitch,248);
		SendSerial("Yaw = ",yaw,248);
		
		USART_SendString("\n\r");
	}
}
