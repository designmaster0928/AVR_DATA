/*
 *  ATmega16 Timer0 delay-10ms 
 *  www.electronicwings.com
 */ 


#include <avr/io.h>

void T0delay();

int main(void)
{
	DDRB = 0xFF;		/*PORTB as output*/
	PORTB = 0;
    while(1)			/*repeat forever*/
    {
		PORTB= ~ PORTB;
		T0delay();
	}
}

void T0delay()
{
	TCCR0 = (1<<CS02) | (1<<CS00);	/*Timer0, normal mode, /1024 prescalar */
	TCNT0 = 0xB2;			/*load TCNT0, count for 10ms*/
	while((TIFR&0x01)==0);  /*wait for TOV0 to roll over */
	TCCR0 = 0;
	TIFR = 0x1;				/*clear TOV0 flag*/
}