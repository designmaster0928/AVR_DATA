/*
 * IR_Serial_Receiver.c
 *
 * Created: 25/10/2016 6:38:00 PM
 *  Author: amrut
 */ 


#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "USART_Interrupt.h"
#include "LCD16x2_4bit.h"
char check,data,invdata,count=0;

ISR(USART_RXC_vect)
{
	if(count == 0)
	{
		if (USART_RxChar() == '$')
		count++;
		
		else
		count=0;
	}
	
	if (count == 1)
	{
		data = USART_RxChar();
		count++;
	}
	
	if (count == 2)
	{
		invdata = USART_RxChar();
		if ((data | invdata)==0xFF)
		{
			lcd_gotoxy(0,0);
			lcddata(data);
		}
	count=0;
	}
}

int main(void)
{
	lcdinit();
	USART_Init(1200);
	lcd_clear();
	sei();
    while(1);
}