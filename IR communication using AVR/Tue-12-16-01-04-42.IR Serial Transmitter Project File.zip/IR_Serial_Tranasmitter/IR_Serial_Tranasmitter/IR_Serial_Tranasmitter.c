/*
 * IR_Serial_Tranasmitter.c
 *
 * Created: 25/10/2016 3:16:03 PM
 *  Author: amrut
 */ 


#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "USART_RS232_H_file.h"
#include "Keypad.h"
char g=0;

ISR(TIMER0_OVF_vect)
{

	g = ~g;
	if (g!=0)
	PORTD |= (1<<7);	
	if (g==0)
	PORTD &= ~(1<<7);
	TCNT0 = 0xF4;
}

void T0dalay2()
{
	TIMSK=(1<<TOIE0);
	TCNT0 = 0xF4;		    /* load TCNT0, count for 10ms */
	TCCR0 = (1<<CS01);		/* Timer0, normal mode, /1024 prescalar */
}

int main(void)
{
	DDRD |= 0xFF;
	USART_Init(1200);
	sei();
	T0dalay2();
	char j,d=0;

	while(1)
	{
		j = keyfind();
		switch (j)
		{
		case ('1'):
			USART_TxChar('$');
			USART_TxChar('1');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
			
		case ('2'):
			USART_TxChar('$');
			USART_TxChar('2');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
			
		case ('3'):
			USART_TxChar('$');
			USART_TxChar('3');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
			
		case ('4'):
			USART_TxChar('$');
			USART_TxChar('4');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
		
		case ('5'):
			USART_TxChar('$');
			USART_TxChar('5');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
		
		case ('6'):
			USART_TxChar('$');
			USART_TxChar('6');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
			
		case ('7'):
			USART_TxChar('$');
			USART_TxChar('7');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
		
		case ('8'):
			USART_TxChar('$');
			USART_TxChar('8');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;

		case ('9'):
			USART_TxChar('$');
			USART_TxChar('9');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;		
		
		case ('0'):
			USART_TxChar('$');
			USART_TxChar('0');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
		
		case ('*'):
			USART_TxChar('$');
			USART_TxChar('*');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;
		
		case ('#'):
			USART_TxChar('$');
			USART_TxChar('#');
			d = ~j;
			USART_TxChar(d);
			_delay_ms(10);
			break;					
		}
	}
}