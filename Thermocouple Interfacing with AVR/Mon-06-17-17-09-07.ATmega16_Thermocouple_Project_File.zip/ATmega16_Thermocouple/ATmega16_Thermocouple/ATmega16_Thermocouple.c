/*
 * ATmega16_Thermocouple.c
 *
 * http://www.electronicwings.com
 */ 


#include <avr/io.h>
#include "LCD16x2_4bit.h"
#include <util/delay.h>
#include <stdio.h>
#include <string.h>

void ADC_Init()
{
	DDRA=0x0;		/* Make ADC port as input */
	ADCSRA = 0x87;	/* Enable ADC, fr/128  */	
}

int adc()
{
	ADMUX = 0x40;					/* Vref: Avcc, ADC channel: 0 */
	ADCSRA |= (1<<ADSC);			/* start conversion */
	while ((ADCSRA &(1<<ADIF))==0);	/*monitor end of conversion interrupt flag */
	ADCSRA |=(1<<ADIF);				/* set the ADIF bit of ADCSRA register */
	return(ADCW);					/* return the ADCW */
}

int main(void)
{
	lcdinit();		/* initialize the 16x2 LCD */
	lcd_clear();	/* clear the LCD */
	ADC_Init();		/* initialize the ADC */
	char array[10];
	int a;
	float b;

    while(1)
	{
		a = adc();				/* store the analog data on a variable */
 		b = (a * 4.88)-0.0027;	/* convert analog voltage into �C 
								   and minus the offset voltage */
 		b = b/10.0;		
		lcd_gotoxy(0,0);		/* set row and column */
		sprintf(array,"Temp = %.2f",b);
		lcd_print(array);	
		lcd_gotoxy(12,0);
		lcddata(0xDF);
		lcd_print("C");	
		_delay_ms(1000);
	}
}