/*
	ATmega16 External interrupt to toggle the PORTC
	http://www.electronicwings.com
*/


#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/*Interrupt Service Routine for INT0*/
ISR(INT0_vect)
{
	PORTC=~PORTC;			/*Toggle PORTC */		
	_delay_ms(50);		   /* Software debouncing control delay */
	
}

int main(void)
{
	DDRC=0xFF;					/*make PORTC as output PORT*/
	PORTC=0;
	DDRD=0;						/*PORTD as input */
	PORTD=0xFF;					/* make pull up high */
	
	GICR = 1<<INT0;					/* Enable INT0*/
	MCUCR = 1<<ISC01 | 1<<ISC00;	/* Trigger INT0 on rising edge */
	
	sei();							/* Enable Global Interrupt */
	
	while(1);
}
