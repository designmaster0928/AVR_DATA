/*
Output Pin Programming to Drive LED
www.electronicwings.com
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRD = 0xFF;	/* Making all 8 pins of Port D as output pins */
	/* 
	In order to make only PD3 as output while keeping direction of other pins as it is, do the following
	DDRD = DDRD | (1<<3);
	This is equivalent to writing one to only PD3 while keeping the other pins unchanged
	*/
    while(1)
    {
        PORTD = PORTD | (1<<3);	/* Making PD3 high. This will make LED ON */
		_delay_ms(100);
		PORTD = PORTD & (~(1<<3));	 /* Making PD3 low. This will make LED OFF */
		_delay_ms(100);
		/* Do not keep very small delay values. Very small delay will lead to LED appearing continuously ON due to persistence of vision */
    }
	return 0;
}