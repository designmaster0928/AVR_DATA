/*
Input Pin Programming 
www.electronicwings.com
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRD = DDRD | (1<<3);	/* Make PD3 as output pin */
	DDRD = DDRD & (~(1<<2));	/* Make PD2 as input pin */
	PORTD = PORTD | (1<<2);		/* Enable pull-up on PD2 by writing 1 to it */
	int pin_status;
    while(1)
    {		
		pin_status = PIND & (1<<2);	/*Read status of pin PD2 */
		if(pin_status)	/* Transmit status of pin PD2 on to pin PD3 to drive LED. */
		{
			PORTD = PORTD | (1<<3);	/* Switch is open, pin_status = 1, LED is ON */
		}
		else
		{		
			PORTD = PORTD & (~(1<<3));   /* Switch is closed, pin_status = 0, LED is OFF */
		}
    }
	return 0;
}