This original Thomas Fischl USBasp firmware can be found under:    
		https://www.fischl.de/usbasp/
