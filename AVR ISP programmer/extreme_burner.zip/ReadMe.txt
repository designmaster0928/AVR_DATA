This zip file is downloaded from Bo, OZ2M: www.rudius.net/oz2m/ngnb/atmel_altprog.htm

The Next Generation Beacons project may be on interest to you: www.rudius.net/oz2m/ngnb

You may also be interested in the RFzero platform: www.rfzero.net
  GPSDO
  frequency counter
  signal generator
  QO-100 LO
  FT4, FT8, JS8, PI4, WSPR 
