/*
 * ATmega16_DFMF_interfacing.c
 *
 * http://www.electronicwings.com
 */ 


#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include "LCD16x2_4bit.h"

bool keydetect = false;

ISR(INT0_vect)
{
	keydetect = true;
	_delay_ms(50);         /* Software debouncing control delay */
}

int main(void)
{
	LCD_Init();			/* initialize the LCD */
	DDRC = 0x00;		/* PORTC define as a input port */
	LCD_String("DTMF");	/* write string on LCD */
	GICR = 1<<INT0;     /* Enable INT0*/
	MCUCR = 1<<ISC01 | 1<<ISC00;     /* Trigger INT0 on rising edge */
		
	sei();              /* Enable Global Interrupt */
   
    while(1)
    {
		_delay_ms(5);
		if (keydetect)
		{
			keydetect = false;
			switch (PINC & 0x0F)
			{
				case (0x01):
				LCD_String_xy(1, 0, "1");
				break;
				
				case (0x02):
				LCD_String_xy(1, 0, "2");
				break;
				
				case (0x03):
				LCD_String_xy(1, 0, "3");
				break;
				
				case (0x04):
				LCD_String_xy(1, 0, "4");
				break;
				
				case (0x05):
				LCD_String_xy(1, 0, "5");
				break;
				
				case (0x06):
				LCD_String_xy(1, 0, "6");
				break;
				
				case (0x07):
				LCD_String_xy(1, 0, "7");
				break;
				
				case (0x08):
				LCD_String_xy(1, 0, "8");
				break;

				case (0x09):
				LCD_String_xy(1, 0, "9");
				break;
				
				case (0x0A):
				LCD_String_xy(1, 0, "0");
				break;
				
				case (0x0B):
				LCD_String_xy(1, 0, "*");
				break;
				
				case (0x0C):
				LCD_String_xy(1, 0, "#");
				break;

				default:
				break;
			}
		}
   }
}