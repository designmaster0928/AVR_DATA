/*
 * ATmega16_Analog_Comparator.c
 *
 * http://www.electronicwings.com
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>

int main()
{
	DDRC |= 0x80;		/* make pin 7 of PORTC is output */
	SFIOR &= (1<<ACME);	/* Enable AIN1 for -ve input */
	ACSR &= 0x00;		/* clear ACSR register */
		
	while(1)
	{
		if (ACSR & (1<<ACO))	/* check ACO bit of ACSR register is high if yes */
		PORTC = 0x80;			/* glow the LED which is connected to PC7 pin (Pin No 29) */
		
		else                    /* if ACO bit is zero */
		PORTC = 0x00;			/* then	turn off LED */
	}	
}