/*
 * ATmega16_BCD_to_7_Segment.c
 *
 * http://www.electronicwings.com
 */ 

#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#define LED_direction DDRA		/* define LED Direction */
#define LED_PORT PORTA			/* define LED PORT */

int main(void)
{
	LED_direction |= 0xff;		/* define port direction is output */
	LED_PORT = 0xff;
	char array[]={0,1,2,3,4,5,6,7,8,9};
								
	while(1)
	{
		for(int i=0;i<10;i++)
		{
			LED_PORT = array[i];/* write data on to the port */
			_delay_ms(1000);	/* wait for 1 second */
		}
	}
}